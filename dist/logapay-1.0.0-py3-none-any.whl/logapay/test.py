# from sdk.logapay import LogapayAPI



# def test_api():
#     TOKEN = "f2df9c9f-e82d-499c-baf5-bc7853f7d21d"
#     TTOKEN = "b57f2db7-b0ed-4c07-a11a-4818bfee412a"
#     test = LogapayAPI(TTOKEN)
    
#     payment = test.payment(50, "658465vgygh")
#     print(payment.get_response())
    
#     # transfer = test.transfer(25, "50948698274", "Yes")
#     # print(transfer)
# if __name__ == "__main__":
#     test_api()
    
    
    